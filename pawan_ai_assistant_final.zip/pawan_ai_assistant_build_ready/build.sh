#!/bin/bash

echo "=========================================="
echo "PAWAN AI ASSISTANT - BUILD SCRIPT"
echo "=========================================="
echo ""

# Check if Flutter is installed
if ! command -v flutter &> /dev/null; then
    echo "❌ Flutter not found!"
    echo "Please install Flutter from: https://flutter.dev"
    echo ""
    echo "Quick install (Linux/Mac):"
    echo "  git clone https://github.com/flutter/flutter.git -b stable"
    echo "  export PATH="$PATH:`pwd`/flutter/bin""
    echo ""
    echo "Quick install (Windows):"
    echo "  Download from https://flutter.dev/docs/get-started/install/windows"
    exit 1
fi

echo "✅ Flutter found:"
flutter --version
echo ""

# Check Flutter doctor
echo "Running Flutter doctor..."
flutter doctor
echo ""

# Get dependencies
echo "📦 Installing dependencies..."
flutter pub get

if [ $? -ne 0 ]; then
    echo "❌ Failed to get dependencies"
    exit 1
fi

echo "✅ Dependencies installed"
echo ""

# Build APK
echo "🔨 Building release APK..."
flutter build apk --release

if [ $? -ne 0 ]; then
    echo "❌ Build failed!"
    echo ""
    echo "Common fixes:"
    echo "  1. Run: flutter clean"
    echo "  2. Run: flutter pub get"
    echo "  3. Check Android SDK is installed"
    echo "  4. Run: flutter doctor -v"
    exit 1
fi

echo ""
echo "=========================================="
echo "✅ BUILD SUCCESSFUL!"
echo "=========================================="
echo ""
echo "Your APK is ready at:"
echo "  build/app/outputs/flutter-apk/app-release.apk"
echo ""
echo "To install on your phone:"
echo "  1. Enable USB debugging on your Android phone"
echo "  2. Connect phone via USB"
echo "  3. Run: flutter install"
echo ""
echo "Or copy the APK to your phone and install it."
echo ""
echo "Enjoy Pawan AI Assistant! 🔥"
echo "=========================================="
