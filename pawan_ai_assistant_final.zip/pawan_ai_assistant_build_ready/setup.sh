#!/bin/bash

echo "================================"
echo "PAWAN AI ASSISTANT - Setup"
echo "================================"
echo ""

# Check Flutter
if ! command -v flutter &> /dev/null; then
    echo "Flutter not found. Please install Flutter first."
    echo "Visit: https://flutter.dev"
    exit 1
fi

echo "Flutter version:"
flutter --version

echo ""
echo "Installing dependencies..."
flutter pub get

echo ""
echo "Checking for issues..."
flutter doctor

echo ""
echo "================================"
echo "Setup Complete!"
echo "================================"
echo ""
echo "Next steps:"
echo "1. Add your logo to assets/images/pawan_logo.png"
echo "2. Add API keys in lib/providers/pawan_provider.dart"
echo "3. Run: flutter run"
echo ""
