#!/bin/bash

echo "=========================================="
echo "PAWAN AI ASSISTANT - ONE-CLICK DEPLOY"
echo "=========================================="
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "Installing Git..."
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        sudo apt-get update && sudo apt-get install -y git
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        brew install git
    else
        echo "Please install Git manually: https://git-scm.com/downloads"
        exit 1
    fi
fi

echo "✅ Git ready"

# Initialize git
git init

# Configure git (user can change later)
git config user.email "pawan@ai.com"
git config user.name "Pawan AI"

# Add all files
git add .

# Commit
git commit -m "🔥 Pawan AI Assistant v1.0 - Initial release

Features:
- Voice control with Ghost Rider theme
- Google Gemini AI integration
- Offline mode support
- 40+ device control features
- Wake word detection (optional)
- Custom voice cloning (optional)"

# Create main branch
git branch -M main

echo ""
echo "=========================================="
echo "REPOSITORY READY!"
echo "=========================================="
echo ""
echo "Next step - Push to GitHub:"
echo ""
echo "1. Create repository at: https://github.com/new"
echo "   Name: pawan-ai-assistant"
echo "   Make it PUBLIC"
echo ""
echo "2. Run these commands:"
echo "   git remote add origin https://github.com/YOUR_USERNAME/pawan-ai-assistant.git"
echo "   git push -u origin main"
echo ""
echo "3. GitHub will automatically build your APK!"
echo "   Go to Actions tab to watch the build"
echo ""
echo "4. Download APK from Releases tab"
echo ""
echo "=========================================="
read -p "Press Enter to continue..."
