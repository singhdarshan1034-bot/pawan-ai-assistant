#!/bin/bash

echo "=========================================="
echo "PAWAN AI - GitHub Setup"
echo "=========================================="
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git not found!"
    echo "Please install Git first: https://git-scm.com/downloads"
    exit 1
fi

echo "✅ Git found"
echo ""

# Initialize git repo if not already
git init

echo "📦 Adding files..."
git add .

echo "💾 Committing..."
git commit -m "Initial commit - Pawan AI Assistant with Gemini API"

echo ""
echo "=========================================="
echo "Next steps:"
echo "=========================================="
echo ""
echo "1. Create a GitHub repository:"
echo "   Go to https://github.com/new"
echo "   Name it: pawan-ai-assistant"
echo "   Make it Public (for free GitHub Actions)"
echo ""
echo "2. Connect and push:"
echo "   git remote add origin https://github.com/YOUR_USERNAME/pawan-ai-assistant.git"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "3. GitHub will automatically build your APK!"
echo "   Go to Actions tab to see the build progress"
echo ""
echo "4. Download APK from Releases:"
echo "   https://github.com/YOUR_USERNAME/pawan-ai-assistant/releases"
echo ""
echo "=========================================="
