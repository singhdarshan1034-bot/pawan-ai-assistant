@echo off
echo ==========================================
echo PAWAN AI ASSISTANT - ONE-CLICK DEPLOY
echo ==========================================
echo.

where git >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ Git not found!
    echo Please install Git from: https://git-scm.com/downloads
    pause
    exit /b 1
)

echo ✅ Git ready
echo.

REM Initialize git
git init

REM Configure git
git config user.email "pawan@ai.com"
git config user.name "Pawan AI"

REM Add all files
git add .

REM Commit
git commit -m "🔥 Pawan AI Assistant v1.0 - Initial release"

REM Create main branch
git branch -M main

echo.
echo ==========================================
echo REPOSITORY READY!
echo ==========================================
echo.
echo Next step - Push to GitHub:
echo.
echo 1. Create repository at: https://github.com/new
echo    Name: pawan-ai-assistant
echo    Make it PUBLIC
echo.
echo 2. Run these commands:
echo    git remote add origin https://github.com/YOUR_USERNAME/pawan-ai-assistant.git
echo    git push -u origin main
echo.
echo 3. GitHub will automatically build your APK!
echo    Go to Actions tab to watch the build
echo.
echo 4. Download APK from Releases tab
echo.
echo ==========================================
pause
