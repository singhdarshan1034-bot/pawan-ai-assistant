@echo off
echo ==========================================
echo PAWAN AI ASSISTANT - BUILD SCRIPT
echo ==========================================
echo.

REM Check if Flutter is installed
where flutter >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ Flutter not found!
    echo Please install Flutter from: https://flutter.dev
    echo.
    pause
    exit /b 1
)

echo ✅ Flutter found:
flutter --version
echo.

REM Get dependencies
echo 📦 Installing dependencies...
flutter pub get

if %errorlevel% neq 0 (
    echo ❌ Failed to get dependencies
    pause
    exit /b 1
)

echo ✅ Dependencies installed
echo.

REM Build APK
echo 🔨 Building release APK...
flutter build apk --release

if %errorlevel% neq 0 (
    echo ❌ Build failed!
    echo.
    echo Common fixes:
    echo   1. Run: flutter clean
    echo   2. Run: flutter pub get
    echo   3. Check Android SDK is installed
    echo   4. Run: flutter doctor -v
    pause
    exit /b 1
)

echo.
echo ==========================================
echo ✅ BUILD SUCCESSFUL!
echo ==========================================
echo.
echo Your APK is ready at:
echo   build\app\outputs\flutter-apk\app-release.apk
echo.
echo To install on your phone:
echo   1. Enable USB debugging on your Android phone
necho   2. Connect phone via USB
echo   3. Run: flutter install
echo.
echo Or copy the APK to your phone and install it.
echo.
echo Enjoy Pawan AI Assistant! 🔥
echo ==========================================
pause
