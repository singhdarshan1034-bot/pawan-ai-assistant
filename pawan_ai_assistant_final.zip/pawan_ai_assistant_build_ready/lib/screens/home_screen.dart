import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:shimmer/shimmer.dart';
import '../providers/pawan_provider.dart';
import '../utils/theme.dart';
import '../widgets/voice_visualizer.dart';
import '../widgets/command_history.dart';
import '../widgets/status_bar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> 
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _rotateController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _rotateController = AnimationController(
      duration: const Duration(seconds: 20),
      vsync: this,
    )..repeat();

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.3).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _rotateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<PawanProvider>(
      builder: (context, pawan, child) {
        if (pawan.isListening) {
          _pulseController.repeat(reverse: true);
        } else {
          _pulseController.stop();
          _pulseController.reset();
        }

        return Scaffold(
          backgroundColor: PawanTheme.backgroundBlack,
          body: SafeArea(
            child: Column(
              children: [
                const StatusBarWidget(),
                Expanded(
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        children: [
                          const SizedBox(height: 20),
                          _buildVoiceActivationArea(pawan),
                          const SizedBox(height: 30),
                          _buildCommandDisplay(pawan),
                          const SizedBox(height: 20),
                          _buildResponseCard(pawan),
                          const SizedBox(height: 20),
                          _buildQuickActionsGrid(pawan),
                          const SizedBox(height: 20),
                          CommandHistoryWidget(history: pawan.commandHistory),
                          const SizedBox(height: 100),
                        ],
                      ),
                    ),
                  ),
                ),
                _buildBottomControlBar(pawan),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildVoiceActivationArea(PawanProvider pawan) {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _rotateController,
          builder: (context, child) {
            return Stack(
              alignment: Alignment.center,
              children: [
                if (pawan.isListening)
                  Transform.rotate(
                    angle: _rotateController.value * 2 * 3.14159,
                    child: Container(
                      width: 280,
                      height: 280,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: PawanTheme.primaryRed.withOpacity(0.3),
                          width: 2,
                        ),
                      ),
                      child: CustomPaint(
                        painter: RingPainter(),
                      ),
                    ),
                  ),
                AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) {
                    return Container(
                      width: 220 * _pulseAnimation.value,
                      height: 220 * _pulseAnimation.value,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            PawanTheme.primaryRed.withOpacity(
                              pawan.isListening ? 0.3 : 0.1),
                            PawanTheme.backgroundBlack.withOpacity(0),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                GestureDetector(
                  onTap: () {
                    HapticFeedback.mediumImpact();
                    if (pawan.isListening) {
                      pawan.stopListening();
                    } else {
                      pawan.startListening();
                    }
                  },
                  child: Container(
                    width: 160,
                    height: 160,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: PawanTheme.primaryRed.withOpacity(
                            pawan.isListening ? 0.6 : 0.2),
                          blurRadius: pawan.isListening ? 40 : 20,
                          spreadRadius: pawan.isListening ? 10 : 5,
                        ),
                      ],
                      border: Border.all(
                        color: PawanTheme.primaryRed.withOpacity(
                          pawan.isListening ? 1.0 : 0.5),
                        width: 3,
                      ),
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/pawan_logo.jpg',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 20),
        if (pawan.isListening)
          VoiceVisualizer(isListening: pawan.isListening)
        else
          Shimmer.fromColors(
            baseColor: PawanTheme.textGray,
            highlightColor: PawanTheme.textWhite,
            child: Text(
              pawan.status,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                fontSize: 18,
                letterSpacing: 2,
              ),
            ),
          ),
        const SizedBox(height: 10),
        Text(
          pawan.isListening ? 'Tap to stop' : 'Tap to speak',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontSize: 12,
            color: PawanTheme.textGray.withOpacity(0.6),
          ),
        ),
      ],
    );
  }

  Widget _buildCommandDisplay(PawanProvider pawan) {
    if (pawan.lastCommand.isEmpty) return const SizedBox.shrink();

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.all(16),
      decoration: PawanTheme.cardDecoration,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.mic, color: PawanTheme.primaryRed, size: 18),
              const SizedBox(width: 8),
              Text(
                'COMMAND',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontSize: 12,
                  letterSpacing: 2,
                  color: PawanTheme.primaryRed,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '"\${pawan.lastCommand}"',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              fontSize: 16,
              fontStyle: FontStyle.italic,
            ),
          ),
          if (pawan.confidence > 0)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: LinearProgressIndicator(
                value: pawan.confidence,
                backgroundColor: PawanTheme.surfaceBlack,
                valueColor: AlwaysStoppedAnimation<Color>(
                  PawanTheme.primaryRed.withOpacity(0.8),
                ),
                minHeight: 2,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildResponseCard(PawanProvider pawan) {
    if (pawan.aiResponse.isEmpty && !pawan.isProcessing) return const SizedBox.shrink();

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.all(16),
      decoration: PawanTheme.cardDecoration.copyWith(
        border: Border.all(
          color: PawanTheme.accentRed.withOpacity(0.4),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.smart_toy, color: PawanTheme.accentRed, size: 18),
              const SizedBox(width: 8),
              Text(
                'PAWAN',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontSize: 12,
                  letterSpacing: 2,
                  color: PawanTheme.accentRed,
                ),
              ),
              if (pawan.isProcessing)
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: SizedBox(
                    width: 12,
                    height: 12,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        PawanTheme.primaryRed,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          if (pawan.isProcessing)
            AnimatedTextKit(
              animatedTexts: [
                TypewriterAnimatedText(
                  'Processing your request...',
                  textStyle: Theme.of(context).textTheme.bodyLarge,
                  speed: const Duration(milliseconds: 50),
                ),
              ],
              totalRepeatCount: 1,
            )
          else
            Text(
              pawan.aiResponse,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                fontSize: 15,
                height: 1.5,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildQuickActionsGrid(PawanProvider pawan) {
    final actions = [
      _QuickAction('SMS', Icons.message, 'Send SMS'),
      _QuickAction('Call', Icons.phone, 'Make Call'),
      _QuickAction('Flash', Icons.flashlight_on, 'Toggle Flash'),
      _QuickAction('Camera', Icons.camera_alt, 'Open Camera'),
      _QuickAction('Alarm', Icons.alarm, 'Set Alarm'),
      _QuickAction('Settings', Icons.settings, 'Open Settings'),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 1,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: actions.length,
      itemBuilder: (context, index) {
        final action = actions[index];
        return GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            _executeQuickAction(action.label, pawan);
          },
          child: Container(
            decoration: PawanTheme.cardDecoration,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(action.icon, color: PawanTheme.primaryRed, size: 28),
                const SizedBox(height: 8),
                Text(
                  action.label,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _executeQuickAction(String label, PawanProvider pawan) {
    switch (label) {
      case 'SMS':
      case 'Call':
      case 'Alarm':
        pawan.startListening();
        break;
      case 'Flash':
        pawan.executeExtendedCommand('flashlight');
        break;
      case 'Camera':
        pawan.executeExtendedCommand('camera');
        break;
      case 'Settings':
        _showSettings(context);
        break;
    }
  }

  Widget _buildBottomControlBar(PawanProvider pawan) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: PawanTheme.cardBlack.withOpacity(0.9),
        border: Border(
          top: BorderSide(
            color: PawanTheme.primaryRed.withOpacity(0.2),
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildControlButton(
            icon: Icons.history,
            label: 'History',
            onTap: () => _showHistory(context, pawan),
          ),
          _buildControlButton(
            icon: pawan.isListening ? Icons.stop : Icons.mic,
            label: pawan.isListening ? 'Stop' : 'Listen',
            isPrimary: true,
            onTap: () {
              HapticFeedback.mediumImpact();
              if (pawan.isListening) {
                pawan.stopListening();
              } else {
                pawan.startListening();
              }
            },
          ),
          _buildControlButton(
            icon: Icons.settings,
            label: 'Settings',
            onTap: () => _showSettings(context),
          ),
        ],
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isPrimary = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: isPrimary ? 70 : 50,
            height: isPrimary ? 70 : 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isPrimary ? PawanTheme.primaryRed : PawanTheme.surfaceBlack,
              boxShadow: isPrimary
                  ? [
                      BoxShadow(
                        color: PawanTheme.primaryRed.withOpacity(0.4),
                        blurRadius: 20,
                        spreadRadius: 5,
                      ),
                    ]
                  : null,
            ),
            child: Icon(
              icon,
              color: PawanTheme.textWhite,
              size: isPrimary ? 32 : 22,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  void _showHistory(BuildContext context, PawanProvider pawan) {
    showModalBottomSheet(
      context: context,
      backgroundColor: PawanTheme.cardBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              'COMMAND HISTORY',
              style: Theme.of(context).textTheme.displayMedium?.copyWith(
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: pawan.commandHistory.length,
                itemBuilder: (context, index) {
                  final cmd = pawan.commandHistory[index];
                  return ListTile(
                    leading: Icon(
                      Icons.mic,
                      color: PawanTheme.primaryRed,
                      size: 18,
                    ),
                    title: Text(
                      cmd.command,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    subtitle: cmd.response != null
                        ? Text(
                            cmd.response!,
                            style: Theme.of(context).textTheme.bodyMedium,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          )
                        : null,
                    trailing: Icon(
                      cmd.status == 'completed'
                          ? Icons.check_circle
                          : Icons.pending,
                      color: cmd.status == 'completed'
                          ? Colors.green
                          : Colors.orange,
                      size: 18,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: PawanTheme.cardBlack,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'SETTINGS',
              style: Theme.of(context).textTheme.displayMedium?.copyWith(
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 20),
            _buildSettingTile('Voice Speed', Icons.speed),
            _buildSettingTile('Wake Word', Icons.record_voice_over),
            _buildSettingTile('AI Model', Icons.psychology),
            _buildSettingTile('Permissions', Icons.security),
            _buildSettingTile('About Pawan', Icons.info),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingTile(String title, IconData icon) {
    return ListTile(
      leading: Icon(icon, color: PawanTheme.primaryRed, size: 22),
      title: Text(title, style: Theme.of(context).textTheme.bodyLarge),
      trailing: const Icon(Icons.chevron_right, color: PawanTheme.textGray),
      onTap: () {},
    );
  }
}

class _QuickAction {
  final String label;
  final IconData icon;
  final String command;

  _QuickAction(this.label, this.icon, this.command);
}

class RingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = PawanTheme.primaryRed.withOpacity(0.6)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 5;

    for (int i = 0; i < 8; i++) {
      final startAngle = (i * 45) * 3.14159 / 180;
      final sweepAngle = 30 * 3.14159 / 180;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        paint..color = PawanTheme.primaryRed.withOpacity(0.3 + (i % 3) * 0.2),
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
