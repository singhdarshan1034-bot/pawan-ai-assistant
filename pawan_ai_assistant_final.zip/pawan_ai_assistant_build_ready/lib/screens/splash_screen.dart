import 'package:flutter/material.dart';
import 'dart:async';
import 'package:animated_text_kit/animated_text_kit.dart';
import '../utils/theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> 
    with TickerProviderStateMixin {
  late AnimationController _logoController;
  late AnimationController _glowController;
  late Animation<double> _logoAnimation;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _logoAnimation = CurvedAnimation(
      parent: _logoController,
      curve: Curves.easeOutBack,
    );

    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _logoController.forward();

    Timer(const Duration(seconds: 4), () {
      Navigator.pushReplacementNamed(context, '/home');
    });
  }

  @override
  void dispose() {
    _logoController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PawanTheme.backgroundBlack,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Animated Logo Container with Ghost Rider
            AnimatedBuilder(
              animation: _glowAnimation,
              builder: (context, child) {
                return Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: PawanTheme.primaryRed.withOpacity(_glowAnimation.value * 0.6),
                        blurRadius: 40,
                        spreadRadius: 10,
                      ),
                      BoxShadow(
                        color: PawanTheme.accentRed.withOpacity(_glowAnimation.value * 0.3),
                        blurRadius: 80,
                        spreadRadius: 20,
                      ),
                    ],
                  ),
                  child: ScaleTransition(
                    scale: _logoAnimation,
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/pawan_logo.jpg',
                        width: 200,
                        height: 200,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 40),
            // Animated Title
            ScaleTransition(
              scale: _logoAnimation,
              child: Text(
                'PAWAN',
                style: Theme.of(context).textTheme.displayLarge?.copyWith(
                  fontSize: 48,
                  letterSpacing: 8,
                  color: PawanTheme.primaryRed,
                  shadows: [
                    Shadow(
                      color: PawanTheme.primaryRed.withOpacity(0.8),
                      blurRadius: 20,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Animated Subtitle
            AnimatedTextKit(
              animatedTexts: [
                TypewriterAnimatedText(
                  'AI ASSISTANT',
                  textStyle: Theme.of(context).textTheme.displayMedium?.copyWith(
                    fontSize: 16,
                    letterSpacing: 4,
                    color: PawanTheme.textGray,
                  ),
                  speed: const Duration(milliseconds: 100),
                ),
                TypewriterAnimatedText(
                  'INITIALIZING...',
                  textStyle: Theme.of(context).textTheme.displayMedium?.copyWith(
                    fontSize: 16,
                    letterSpacing: 4,
                    color: PawanTheme.textGray,
                  ),
                  speed: const Duration(milliseconds: 100),
                ),
              ],
              totalRepeatCount: 1,
            ),
            const SizedBox(height: 60),
            // Loading Indicator
            SizedBox(
              width: 200,
              child: LinearProgressIndicator(
                backgroundColor: PawanTheme.surfaceBlack,
                valueColor: AlwaysStoppedAnimation<Color>(
                  PawanTheme.primaryRed.withOpacity(0.8),
                ),
                minHeight: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
