import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PawanTheme {
  static const Color primaryRed = Color(0xFFE53935);
  static const Color darkRed = Color(0xFFB71C1C);
  static const Color accentRed = Color(0xFFFF1744);
  static const Color backgroundBlack = Color(0xFF0A0A0A);
  static const Color surfaceBlack = Color(0xFF1A1A1A);
  static const Color cardBlack = Color(0xFF121212);
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textGray = Color(0xFFB0B0B0);
  static const Color glowRed = Color(0xFFFF5252);

  static ThemeData get darkTheme {
    return ThemeData.dark().copyWith(
      scaffoldBackgroundColor: backgroundBlack,
      primaryColor: primaryRed,
      colorScheme: const ColorScheme.dark(
        primary: primaryRed,
        secondary: accentRed,
        surface: surfaceBlack,
        background: backgroundBlack,
        onPrimary: textWhite,
        onSecondary: textWhite,
        onSurface: textWhite,
        onBackground: textWhite,
      ),
      textTheme: TextTheme(
        displayLarge: GoogleFonts.orbitron(
          color: textWhite,
          fontSize: 32,
          fontWeight: FontWeight.bold,
        ),
        displayMedium: GoogleFonts.orbitron(
          color: primaryRed,
          fontSize: 24,
          fontWeight: FontWeight.w600,
        ),
        headlineLarge: GoogleFonts.orbitron(
          color: textWhite,
          fontSize: 20,
        ),
        bodyLarge: GoogleFonts.roboto(
          color: textWhite,
          fontSize: 16,
        ),
        bodyMedium: GoogleFonts.roboto(
          color: textGray,
          fontSize: 14,
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: cardBlack.withOpacity(0.8),
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.orbitron(
          color: primaryRed,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      cardTheme: CardTheme(
        color: cardBlack,
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: primaryRed.withOpacity(0.3), width: 1),
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: primaryRed,
        foregroundColor: textWhite,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: cardBlack,
        selectedItemColor: primaryRed,
        unselectedItemColor: textGray,
      ),
    );
  }

  static BoxDecoration get glowDecoration {
    return BoxDecoration(
      shape: BoxShape.circle,
      boxShadow: [
        BoxShadow(
          color: primaryRed.withOpacity(0.4),
          blurRadius: 30,
          spreadRadius: 5,
        ),
        BoxShadow(
          color: accentRed.withOpacity(0.2),
          blurRadius: 60,
          spreadRadius: 10,
        ),
      ],
    );
  }

  static BoxDecoration get cardDecoration {
    return BoxDecoration(
      color: cardBlack,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: primaryRed.withOpacity(0.2)),
      boxShadow: [
        BoxShadow(
          color: primaryRed.withOpacity(0.1),
          blurRadius: 10,
          offset: const Offset(0, 4),
        ),
      ],
    );
  }
}
