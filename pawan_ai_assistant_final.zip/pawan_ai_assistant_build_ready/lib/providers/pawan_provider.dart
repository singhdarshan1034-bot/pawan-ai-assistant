import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:connectivity_plus/connectivity_plus.dart';
import 'services/command_processor.dart';
import 'services/device_controller.dart';
import 'services/offline/offline_processor.dart';
import 'services/wake_word/wake_word_service.dart';
import 'services/voice/custom_voice_service.dart';
import 'services/device_controller_extended.dart';
import 'models/command_model.dart';

class PawanProvider extends ChangeNotifier {
  // Speech & TTS
  final SpeechToText _speech = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  // Services
  final CommandProcessor _commandProcessor = CommandProcessor();
  final DeviceController _deviceController = DeviceController();
  final ExtendedDeviceController _extendedController = ExtendedDeviceController();
  final WakeWordService _wakeWordService = WakeWordService();
  final CustomVoiceService _customVoice = CustomVoiceService();

  // State
  bool _isListening = false;
  bool _isSpeaking = false;
  bool _isProcessing = false;
  bool _isOnline = true;
  bool _wakeWordEnabled = false;
  String _lastCommand = '';
  String _aiResponse = '';
  List<CommandModel> _commandHistory = [];
  double _confidence = 0.0;
  String _status = 'Pawan is ready';
  String _currentMode = 'Online';

  // Getters
  bool get isListening => _isListening;
  bool get isSpeaking => _isSpeaking;
  bool get isProcessing => _isProcessing;
  bool get isOnline => _isOnline;
  bool get wakeWordEnabled => _wakeWordEnabled;
  String get lastCommand => _lastCommand;
  String get aiResponse => _aiResponse;
  String get status => _status;
  String get currentMode => _currentMode;
  List<CommandModel> get commandHistory => _commandHistory;
  double get confidence => _confidence;

  // Gemini API Configuration
  static const String _geminiApiKey = 'AQ.Ab8RN6I8MMABNHnyov0dMef3AV4G4pHBaiDZT7RAJYrp0eeIsg';
  static const String _geminiApiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

  PawanProvider() {
    _initPawan();
  }

  Future<void> _initPawan() async {
    await _initSpeech();
    await _initTTS();
    await _customVoice.initialize();
    await _checkConnectivity();
    await _speakWelcome();

    // Monitor connectivity
    Connectivity().onConnectivityChanged.listen((result) {
      _isOnline = result != ConnectivityResult.none;
      _currentMode = _isOnline ? 'Online' : 'Offline';
      notifyListeners();
    });
  }

  Future<void> _initSpeech() async {
    await _speech.initialize(
      onError: (error) => _handleError(error.errorMsg),
      onStatus: (status) => debugPrint('Speech status: \$status'),
    );
  }

  Future<void> _initTTS() async {
    await _tts.setLanguage('en-US');
    await _tts.setPitch(1.1);
    await _tts.setSpeechRate(0.45);
    await _tts.setVolume(1.0);

    var voices = await _tts.getVoices;
    for (var voice in voices) {
      if (voice.toString().contains('male') || voice.toString().contains('Male')) {
        await _tts.setVoice(voice);
        break;
      }
    }

    _tts.setCompletionHandler(() {
      _isSpeaking = false;
      notifyListeners();
    });

    _tts.setStartHandler(() {
      _isSpeaking = true;
      notifyListeners();
    });
  }

  Future<void> _checkConnectivity() async {
    final result = await Connectivity().checkConnectivity();
    _isOnline = result != ConnectivityResult.none;
    _currentMode = _isOnline ? 'Online' : 'Offline';
  }

  Future<void> _speakWelcome() async {
    await Future.delayed(const Duration(seconds: 1));
    await _speak("Pawan online. System initialized. Ready to assist you, sir.");
  }

  Future<void> _speak(String text) async {
    _aiResponse = text;
    notifyListeners();
    await _customVoice.speak(text);
  }

  // Toggle Wake Word Detection
  Future<void> toggleWakeWord() async {
    if (_wakeWordEnabled) {
      await _wakeWordService.stopListening();
      _wakeWordEnabled = false;
      _status = 'Wake word disabled';
    } else {
      await _wakeWordService.initialize(
        onWakeWord: () {
          _status = 'Wake word detected!';
          notifyListeners();
          startListening();
        },
        onCommand: (command) {
          if (command != 'unknown') {
            _processCommand(command);
          }
        },
      );
      await _wakeWordService.startListening();
      _wakeWordEnabled = true;
      _status = 'Say "Hey Pawan" to activate';
    }
    notifyListeners();
  }

  // Start Listening
  Future<void> startListening() async {
    if (!_speech.isAvailable) {
      _status = 'Speech recognition not available';
      notifyListeners();
      return;
    }

    _isListening = true;
    _status = 'Listening...';
    notifyListeners();

    await _speech.listen(
      onResult: (result) {
        _lastCommand = result.recognizedWords;
        _confidence = result.confidence;
        notifyListeners();

        if (result.finalResult) {
          _processCommand(_lastCommand);
        }
      },
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
      cancelOnError: true,
      listenMode: ListenMode.confirmation,
    );
  }

  // Stop Listening
  Future<void> stopListening() async {
    _isListening = false;
    _status = 'Processing...';
    await _speech.stop();
    notifyListeners();
  }

  // Process Command
  Future<void> _processCommand(String command) async {
    _isListening = false;
    _isProcessing = true;
    _status = 'Processing command...';
    notifyListeners();

    try {
      _commandHistory.insert(0, CommandModel(
        command: command,
        timestamp: DateTime.now(),
        status: 'processing',
      ));

      // Try offline processing first
      if (!_isOnline || OfflineProcessor.canHandleOffline(command)) {
        final offlineResponse = OfflineProcessor.processOffline(command);
        if (offlineResponse != null) {
          await _speak(offlineResponse);
          _currentMode = 'Offline';
          _commandHistory[0] = CommandModel(
            command: command,
            response: offlineResponse,
            timestamp: DateTime.now(),
            status: 'completed',
          );
          _isProcessing = false;
          _status = 'Pawan is ready';
          notifyListeners();
          return;
        }
      }

      // Check for device commands
      final deviceAction = _commandProcessor.parseDeviceCommand(command);
      if (deviceAction != null) {
        await _executeDeviceCommand(deviceAction, command);
      } else {
        // Send to Gemini AI
        await _processWithGemini(command);
      }

      _commandHistory[0] = CommandModel(
        command: command,
        response: _aiResponse,
        timestamp: DateTime.now(),
        status: 'completed',
      );

    } catch (e) {
      _status = 'Error: \$e';
      await _speak("I apologize, I encountered an error. Please try again.");
    } finally {
      _isProcessing = false;
      _status = 'Pawan is ready';
      notifyListeners();
    }
  }

  // Execute Device Commands
  Future<void> _executeDeviceCommand(DeviceAction action, String command) async {
    switch (action) {
      case DeviceAction.sendSMS:
        await _deviceController.sendSMS(command);
        await _speak("Message sent successfully.");
        break;
      case DeviceAction.makeCall:
        await _deviceController.makeCall(command);
        await _speak("Initiating call.");
        break;
      case DeviceAction.toggleFlashlight:
        await _deviceController.toggleFlashlight();
        await _speak("Flashlight toggled.");
        break;
      case DeviceAction.openApp:
        await _deviceController.openApp(command);
        await _speak("Opening application.");
        break;
      case DeviceAction.setAlarm:
        await _deviceController.setAlarm(command);
        await _speak("Alarm set.");
        break;
      case DeviceAction.takePhoto:
        await _deviceController.takePhoto();
        await _speak("Camera opened.");
        break;
      case DeviceAction.unknown:
        await _processWithGemini(command);
        break;
    }
  }

  // Extended Device Commands
  Future<void> executeExtendedCommand(String type, {String? param}) async {
    switch (type.toLowerCase()) {
      case 'wifi':
        await _extendedController.toggleWiFi();
        await _speak("Opening WiFi settings.");
        break;
      case 'bluetooth':
        await _extendedController.toggleBluetooth();
        await _speak("Opening Bluetooth settings.");
        break;
      case 'volume':
        if (param != null) {
          final level = double.tryParse(param) ?? 0.5;
          await _extendedController.setVolume(level);
          await _speak("Volume adjusted.");
        }
        break;
      case 'brightness':
        if (param != null) {
          final level = double.tryParse(param) ?? 0.5;
          await _extendedController.setBrightness(level);
          await _speak("Brightness adjusted.");
        }
        break;
      case 'screenshot':
        await _extendedController.takeScreenshot();
        await _speak("Screenshot captured.");
        break;
      case 'lock':
        await _extendedController.lockScreen();
        await _speak("Locking device.");
        break;
      case 'battery':
        final level = await _extendedController.getBatteryLevel();
        await _speak("Battery level is \$level percent.");
        break;
      case 'dnd':
        await _extendedController.toggleDoNotDisturb();
        await _speak("Do not disturb toggled.");
        break;
      case 'airplane':
        await _extendedController.toggleAirplaneMode();
        await _speak("Airplane mode toggled.");
        break;
      case 'hotspot':
        await _extendedController.toggleHotspot();
        await _speak("Hotspot toggled.");
        break;
      case 'find':
        await _extendedController.findMyPhone();
        await _speak("Finding your phone.");
        break;
      case 'maps':
        if (param != null) {
          await _extendedController.openMaps(param);
          await _speak("Opening maps for \$param.");
        }
        break;
      case 'browser':
        if (param != null) {
          await _extendedController.openBrowser(param);
          await _speak("Opening browser.");
        }
        break;
      case 'calculator':
        await _extendedController.openCalculator();
        await _speak("Opening calculator.");
        break;
      case 'calendar':
        await _extendedController.openCalendar();
        await _speak("Opening calendar.");
        break;
      case 'timer':
        if (param != null) {
          final minutes = int.tryParse(param) ?? 5;
          await _extendedController.startTimer(minutes);
          await _speak("Timer set for \$minutes minutes.");
        }
        break;
      case 'copy':
        if (param != null) {
          await _extendedController.copyToClipboard(param);
          await _speak("Copied to clipboard.");
        }
        break;
      case 'paste':
        final text = await _extendedController.pasteFromClipboard();
        await _speak("Clipboard content: \$text");
        break;
    }
  }

  // Gemini AI Processing
  Future<void> _processWithGemini(String command) async {
    if (!_isOnline) {
      await _speak("I'm currently offline. Please check your internet connection.");
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('\$_geminiApiUrl?key=\$_geminiApiKey'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'contents': [
            {
              'role': 'user',
              'parts': [
                {
                  'text': '''You are Pawan, an advanced AI assistant similar to Jarvis from Iron Man. 
                  You are loyal, witty, and highly efficient. Speak with confidence and authority.
                  Keep responses concise (under 50 words). Use phrases like "At your service", "Right away", "Consider it done".
                  You can help with: general questions, calculations, weather, time, reminders, jokes, and device control.
                  Always refer to yourself as Pawan.

                  User command: \$command'''
                }
              ]
            }
          ],
          'generationConfig': {
            'temperature': 0.7,
            'maxOutputTokens': 150,
          }
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final aiText = data['candidates'][0]['content']['parts'][0]['text'];
        await _speak(aiText);
      } else {
        await _speak("I'm having trouble connecting to my neural network. Operating in offline mode.");
      }
    } catch (e) {
      await _speak("Network connection failed. Operating in offline mode.");
    }
  }

  // Set Voice Type
  void setVoiceType(String type) {
    switch (type) {
      case 'system':
        _customVoice.setVoiceType(VoiceType.system);
        break;
      case 'elevenlabs':
        _customVoice.setVoiceType(VoiceType.elevenLabs);
        break;
      case 'coqui':
        _customVoice.setVoiceType(VoiceType.coqui);
        break;
      case 'piper':
        _customVoice.setVoiceType(VoiceType.piper);
        break;
    }
  }

  void _handleError(String error) {
    _status = 'Error: \$error';
    notifyListeners();
  }

  void clearHistory() {
    _commandHistory.clear();
    notifyListeners();
  }

  @override
  void dispose() {
    _speech.stop();
    _tts.stop();
    _wakeWordService.dispose();
    _customVoice.dispose();
    super.dispose();
  }
}
