class CommandModel {
  final String command;
  final String? response;
  final DateTime timestamp;
  final String status;

  CommandModel({
    required this.command,
    this.response,
    required this.timestamp,
    required this.status,
  });
}

enum DeviceAction {
  sendSMS,
  makeCall,
  toggleFlashlight,
  openApp,
  setAlarm,
  takePhoto,
  unknown,
}
