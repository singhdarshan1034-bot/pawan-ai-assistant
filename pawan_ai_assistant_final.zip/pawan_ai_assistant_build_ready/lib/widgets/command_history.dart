import 'package:flutter/material.dart';
import '../models/command_model.dart';
import '../utils/theme.dart';

class CommandHistoryWidget extends StatelessWidget {
  final List<CommandModel> history;

  const CommandHistoryWidget({super.key, required this.history});

  @override
  Widget build(BuildContext context) {
    if (history.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.history,
              color: PawanTheme.primaryRed,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(
              'RECENT COMMANDS',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontSize: 12,
                letterSpacing: 2,
                color: PawanTheme.primaryRed,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: history.length.clamp(0, 5),
          itemBuilder: (context, index) {
            final cmd = history[index];
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: PawanTheme.cardBlack,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: PawanTheme.primaryRed.withOpacity(0.1),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: cmd.status == 'completed'
                          ? Colors.green
                          : Colors.orange,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          cmd.command,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            fontSize: 14,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (cmd.response != null)
                          Text(
                            cmd.response!,
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              fontSize: 12,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                      ],
                    ),
                  ),
                  Icon(
                    Icons.chevron_right,
                    color: PawanTheme.textGray.withOpacity(0.5),
                    size: 18,
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}
