import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

enum VoiceType {
  system,      // Default device TTS
  elevenLabs,  // ElevenLabs AI voice clone
  coqui,       // Coqui TTS (open source)
  piper,       // Piper TTS (offline, lightweight)
}

class CustomVoiceService {
  final FlutterTts _tts = FlutterTts();
  VoiceType _currentVoice = VoiceType.system;

  // ElevenLabs API (for voice cloning)
  static const String _elevenLabsApiKey = 'YOUR_ELEVENLABS_API_KEY';
  static const String _elevenLabsApiUrl = 'https://api.elevenlabs.io/v1';
  String? _voiceId; // Your cloned voice ID

  // Cached audio files
  Map<String, String> _audioCache = {};

  Future<void> initialize() async {
    await _initSystemVoice();
    await _loadCache();
  }

  Future<void> _initSystemVoice() async {
    await _tts.setLanguage('en-US');
    await _tts.setPitch(1.1);
    await _tts.setSpeechRate(0.45);
    await _tts.setVolume(1.0);

    // Try to find a male voice
    var voices = await _tts.getVoices;
    for (var voice in voices) {
      final voiceMap = voice as Map<dynamic, dynamic>;
      final name = voiceMap['name']?.toString().toLowerCase() ?? '';
      if (name.contains('male') || name.contains('david') || name.contains('james')) {
        await _tts.setVoice(voiceMap);
        break;
      }
    }
  }

  /// Set voice type
  void setVoiceType(VoiceType type) {
    _currentVoice = type;
  }

  /// Speak text with selected voice
  Future<void> speak(String text) async {
    switch (_currentVoice) {
      case VoiceType.system:
        await _speakSystem(text);
        break;
      case VoiceType.elevenLabs:
        await _speakElevenLabs(text);
        break;
      case VoiceType.coqui:
        await _speakCoqui(text);
        break;
      case VoiceType.piper:
        await _speakPiper(text);
        break;
    }
  }

  /// System TTS (default)
  Future<void> _speakSystem(String text) async {
    await _tts.speak(text);
  }

  /// ElevenLabs AI Voice (requires API key and voice clone)
  Future<void> _speakElevenLabs(String text) async {
    if (_voiceId == null) {
      // Fallback to system voice
      await _speakSystem(text);
      return;
    }

    try {
      // Check cache first
      final cacheKey = _generateCacheKey(text);
      if (_audioCache.containsKey(cacheKey)) {
        await _playAudioFile(_audioCache[cacheKey]!);
        return;
      }

      // Generate speech via ElevenLabs API
      final response = await http.post(
        Uri.parse('\$_elevenLabsApiUrl/text-to-speech/\$_voiceId'),
        headers: {
          'xi-api-key': _elevenLabsApiKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'text': text,
          'model_id': 'eleven_monolingual_v1',
          'voice_settings': {
            'stability': 0.5,
            'similarity_boost': 0.8,
          },
        }),
      );

      if (response.statusCode == 200) {
        // Save audio file
        final dir = await getApplicationDocumentsDirectory();
        final filePath = '\${dir.path}/\$cacheKey.mp3';
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);

        _audioCache[cacheKey] = filePath;
        await _saveCache();
        await _playAudioFile(filePath);
      } else {
        await _speakSystem(text);
      }
    } catch (e) {
      debugPrint('ElevenLabs error: \$e');
      await _speakSystem(text);
    }
  }

  /// Coqui TTS (Open source, can run locally)
  Future<void> _speakCoqui(String text) async {
    // Requires local Coqui TTS server or model
    // For now, fallback to system
    await _speakSystem(text);
  }

  /// Piper TTS (Offline, lightweight)
  Future<void> _speakPiper(String text) async {
    // Requires piper-tts binary and model files
    // For now, fallback to system
    await _speakSystem(text);
  }

  /// Clone your voice using ElevenLabs
  Future<String?> cloneVoice({
    required List<String> audioSamplePaths,
    required String voiceName,
  }) async {
    try {
      // This requires uploading audio samples to ElevenLabs
      // Implementation depends on their API

      // For now, return a placeholder
      // In production, you'd upload files and get a voice_id
      _voiceId = 'your_cloned_voice_id';
      return _voiceId;
    } catch (e) {
      debugPrint('Voice cloning error: \$e');
      return null;
    }
  }

  /// Play audio file
  Future<void> _playAudioFile(String path) async {
    // Use audio player plugin to play the file
    // For now, just use system TTS as fallback
    await _speakSystem('Audio playback not implemented in this version');
  }

  String _generateCacheKey(String text) {
    return text.hashCode.toString();
  }

  Future<void> _loadCache() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final cacheFile = File('\${dir.path}/voice_cache.json');
      if (await cacheFile.exists()) {
        final json = await cacheFile.readAsString();
        _audioCache = Map<String, String>.from(jsonDecode(json));
      }
    } catch (e) {
      debugPrint('Cache load error: \$e');
    }
  }

  Future<void> _saveCache() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final cacheFile = File('\${dir.path}/voice_cache.json');
      await cacheFile.writeAsString(jsonEncode(_audioCache));
    } catch (e) {
      debugPrint('Cache save error: \$e');
    }
  }

  void dispose() {
    _tts.stop();
  }
}
