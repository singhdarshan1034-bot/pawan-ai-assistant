import 'dart:math';
import '../../models/command_model.dart';

class OfflineProcessor {
  // Local command patterns for offline processing
  static final Map<String, List<String>> _commandPatterns = {
    'time': ['time', 'clock', 'what time', 'current time'],
    'date': ['date', 'today', 'what day', 'current date'],
    'battery': ['battery', 'charge', 'power level'],
    'flashlight': ['flashlight', 'torch', 'light'],
    'wifi': ['wifi', 'internet', 'network'],
    'bluetooth': ['bluetooth', 'pair', 'connect device'],
    'volume': ['volume', 'loud', 'quiet', 'mute', 'sound'],
    'brightness': ['brightness', 'screen', 'dim', 'bright'],
    'calculator': ['calculate', 'plus', 'minus', 'times', 'divided by', 'math'],
    'weather': ['weather', 'temperature', 'forecast'],
    'joke': ['joke', 'funny', 'laugh', 'humor'],
    'quote': ['quote', 'inspiration', 'motivation'],
    'fact': ['fact', 'trivia', 'did you know'],
    'greeting': ['hello', 'hi', 'hey', 'good morning', 'good evening'],
    'farewell': ['bye', 'goodbye', 'see you', 'later'],
    'thanks': ['thank', 'thanks', 'appreciate'],
  };

  // Response templates
  static final Map<String, List<String>> _responses = {
    'time': [
      "The current time is {time}. At your service.",
      "It's {time}, sir.",
      "Time check: {time}.",
    ],
    'date': [
      "Today is {date}.",
      "The date is {date}, sir.",
      "It's {date} today.",
    ],
    'battery': [
      "I cannot directly check battery levels without system access, but you can check in your device settings.",
      "Battery status requires system-level permissions. Please check your status bar.",
    ],
    'flashlight': [
      "Flashlight toggled. Let there be light.",
      "Illuminating your surroundings, sir.",
      "Flashlight activated.",
    ],
    'wifi': [
      "WiFi settings would need to be adjusted through your system settings.",
      "I can guide you to WiFi settings. Would you like me to open them?",
    ],
    'bluetooth': [
      "Bluetooth control requires system permissions. Opening settings for you.",
      "I can help you navigate to Bluetooth settings.",
    ],
    'volume': [
      "Volume adjustment requires system access. Please use your device buttons.",
      "I can guide you to sound settings if needed.",
    ],
    'brightness': [
      "Screen brightness can be adjusted in your quick settings panel.",
      "I recommend using your device's brightness slider for optimal control.",
    ],
    'calculator': [
      "The answer is {result}.",
      "Calculated: {result}.",
      "That equals {result}, sir.",
    ],
    'weather': [
      "I'm currently operating offline. For real-time weather, please connect to the internet.",
      "Weather data requires an internet connection. Please check your network.",
    ],
    'joke': [
      "Why don't scientists trust atoms? Because they make up everything!",
      "I told my computer I needed a break, and now it won't stop sending me Kit-Kats.",
      "Why did the scarecrow win an award? Because he was outstanding in his field!",
      "I'm reading a book on anti-gravity. It's impossible to put down!",
      "Why do programmers prefer dark mode? Because light attracts bugs!",
    ],
    'quote': [
      "The only way to do great work is to love what you do. - Steve Jobs",
      "Innovation distinguishes between a leader and a follower. - Steve Jobs",
      "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
      "Success is not final, failure is not fatal: it is the courage to continue that counts. - Churchill",
    ],
    'fact': [
      "Honey never spoils. Archaeologists have found 3000-year-old honey in Egyptian tombs that was still edible.",
      "Octopuses have three hearts, blue blood, and nine brains.",
      "Bananas are berries, but strawberries are not.",
      "A day on Venus is longer than a year on Venus.",
    ],
    'greeting': [
      "Greetings, sir. Pawan at your service.",
      "Hello! Ready to assist you.",
      "Good to see you. How may I help?",
    ],
    'farewell': [
      "Goodbye, sir. Pawan standing by.",
      "Until next time. I'll be here.",
      "Farewell. System remaining active.",
    ],
    'thanks': [
      "You're welcome, sir. Always at your service.",
      "My pleasure. That's what I'm here for.",
      "Anytime. Pawan is always ready to assist.",
    ],
  };

  /// Process command offline and return response
  static String? processOffline(String command) {
    final lowerCommand = command.toLowerCase();

    // Check each command pattern
    for (final entry in _commandPatterns.entries) {
      for (final pattern in entry.value) {
        if (lowerCommand.contains(pattern)) {
          return _generateResponse(entry.key, command);
        }
      }
    }

    return null; // No offline match found
  }

  static String _generateResponse(String key, String originalCommand) {
    final responses = _responses[key] ?? ["I'm not sure about that."];
    final random = Random();
    String response = responses[random.nextInt(responses.length)];

    // Replace placeholders
    final now = DateTime.now();

    if (response.contains('{time}')) {
      final timeStr = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";
      response = response.replaceAll('{time}', timeStr);
    }

    if (response.contains('{date}')) {
      final days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      final months = ['January', 'February', 'March', 'April', 'May', 'June', 
                      'July', 'August', 'September', 'October', 'November', 'December'];
      final dateStr = "${days[now.weekday - 1]}, ${months[now.month - 1]} ${now.day}, ${now.year}";
      response = response.replaceAll('{date}', dateStr);
    }

    if (response.contains('{result}')) {
      final result = _calculate(originalCommand);
      response = response.replaceAll('{result}', result);
    }

    return response;
  }

  static String _calculate(String command) {
    try {
      // Simple calculation extraction
      final clean = command.toLowerCase()
          .replaceAll('calculate', '')
          .replaceAll('what is', '')
          .replaceAll('what's', '')
          .replaceAll('plus', '+')
          .replaceAll('minus', '-')
          .replaceAll('times', '*')
          .replaceAll('divided by', '/')
          .replaceAll('multiplied by', '*')
          .trim();

      // Extract numbers and operators
      final numbers = RegExp(r'[-+]?\d*\.?\d+').allMatches(clean)
          .map((m) => double.parse(m.group(0)!))
          .toList();

      if (numbers.length >= 2) {
        if (clean.contains('+')) return (numbers[0] + numbers[1]).toString();
        if (clean.contains('-')) return (numbers[0] - numbers[1]).toString();
        if (clean.contains('*') || clean.contains('x')) return (numbers[0] * numbers[1]).toString();
        if (clean.contains('/')) return numbers[1] != 0 ? (numbers[0] / numbers[1]).toString() : 'Error';
      }

      return 'unable to calculate';
    } catch (e) {
      return 'calculation error';
    }
  }

  /// Check if command can be handled offline
  static bool canHandleOffline(String command) {
    final lowerCommand = command.toLowerCase();
    for (final patterns in _commandPatterns.values) {
      for (final pattern in patterns) {
        if (lowerCommand.contains(pattern)) return true;
      }
    }
    return false;
  }
}
