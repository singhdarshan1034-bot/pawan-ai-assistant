import 'package:url_launcher/url_launcher.dart';
import 'package:torch_controller/torch_controller.dart';

class DeviceController {
  final TorchController _torch = TorchController();

  Future<void> sendSMS(String command) async {
    // Extract phone number and message from command
    final phoneNumber = _extractPhoneNumber(command);
    final message = _extractMessage(command);

    final Uri smsUri = Uri(
      scheme: 'sms',
      path: phoneNumber,
      queryParameters: {'body': message},
    );

    if (await canLaunchUrl(smsUri)) {
      await launchUrl(smsUri);
    }
  }

  Future<void> makeCall(String command) async {
    final phoneNumber = _extractPhoneNumber(command);
    final Uri callUri = Uri(scheme: 'tel', path: phoneNumber);

    if (await canLaunchUrl(callUri)) {
      await launchUrl(callUri);
    }
  }

  Future<void> toggleFlashlight() async {
    await _torch.toggle();
  }

  Future<void> openApp(String command) async {
    // Extract app name and try to open
    final appName = _extractAppName(command);
    // Implementation depends on platform
  }

  Future<void> setAlarm(String command) async {
    final time = _extractTime(command);
    final Uri alarmUri = Uri.parse('clock://setAlarm?time=$time');
    if (await canLaunchUrl(alarmUri)) {
      await launchUrl(alarmUri);
    }
  }

  Future<void> takePhoto() async {
    final Uri cameraUri = Uri.parse('camera://');
    if (await canLaunchUrl(cameraUri)) {
      await launchUrl(cameraUri);
    }
  }

  // Helper methods
  String _extractPhoneNumber(String command) {
    // Simple extraction - improve with regex
    final words = command.split(' ');
    for (var word in words) {
      if (word.contains(RegExp(r'[0-9]'))) {
        return word.replaceAll(RegExp(r'[^0-9]'), '');
      }
    }
    return '';
  }

  String _extractMessage(String command) {
    final parts = command.split('saying');
    if (parts.length > 1) return parts[1].trim();
    return '';
  }

  String _extractAppName(String command) {
    final words = command.split(' ');
    final openIndex = words.indexOf('open');
    if (openIndex != -1 && openIndex + 1 < words.length) {
      return words[openIndex + 1];
    }
    return '';
  }

  String _extractTime(String command) {
    // Extract time like "7 AM" or "14:30"
    final match = RegExp(r'(\d{1,2})\s*(AM|PM|am|pm)?').firstMatch(command);
    if (match != null) {
      return match.group(0) ?? '';
    }
    return '';
  }
}
