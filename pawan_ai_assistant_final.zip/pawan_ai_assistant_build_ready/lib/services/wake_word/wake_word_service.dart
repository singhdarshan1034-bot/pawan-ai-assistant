import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:picovoice/picovoice_manager.dart';
import 'package:picovoice/picovoice_error.dart';

class WakeWordService {
  static const String _accessKey = 'YOUR_PICOVOICE_ACCESS_KEY';

  PicovoiceManager? _picovoiceManager;
  bool _isListening = false;
  Function(String)? _onCommandDetected;
  Function()? _onWakeWordDetected;

  // Wake word model path (you need to train "Hey Pawan" at picovoice.ai)
  static const String _keywordPath = 'assets/models/hey-pawan.ppn';

  // Context file for commands (trained at picovoice.ai)
  static const String _contextPath = 'assets/models/pawan-commands.rhn';

  bool get isListening => _isListening;

  /// Initialize wake word detection
  Future<void> initialize({
    required Function() onWakeWord,
    required Function(String command) onCommand,
  }) async {
    _onWakeWordDetected = onWakeWord;
    _onCommandDetected = onCommand;

    try {
      _picovoiceManager = await PicovoiceManager.create(
        _accessKey,
        _keywordPath,
        _wakeWordCallback,
        _contextPath,
        _inferenceCallback,
        porcupineSensitivity: 0.7,
        rhinoSensitivity: 0.6,
      );
      debugPrint('Wake word service initialized');
    } on PicovoiceException catch (ex) {
      debugPrint('Failed to initialize wake word: \$ex');
      // Fallback to manual listening
    }
  }

  /// Start always-listening wake word detection
  Future<void> startListening() async {
    if (_picovoiceManager == null) return;

    try {
      await _picovoiceManager!.start();
      _isListening = true;
      debugPrint('Wake word detection started - Say "Hey Pawan"');
    } on PicovoiceException catch (ex) {
      debugPrint('Failed to start listening: \$ex');
    }
  }

  /// Stop wake word detection
  Future<void> stopListening() async {
    if (_picovoiceManager == null) return;

    try {
      await _picovoiceManager!.stop();
      _isListening = false;
    } on PicovoiceException catch (ex) {
      debugPrint('Failed to stop listening: \$ex');
    }
  }

  /// Called when "Hey Pawan" is detected
  void _wakeWordCallback() {
    debugPrint('WAKE WORD DETECTED: Hey Pawan!');
    _onWakeWordDetected?.call();
  }

  /// Called when a command is recognized after wake word
  void _inferenceCallback(Map<String, dynamic> inference) {
    final isUnderstood = inference['isUnderstood'] as bool? ?? false;

    if (isUnderstood) {
      final intent = inference['intent'] as String? ?? '';
      final slots = inference['slots'] as Map<String, dynamic>? ?? {};

      // Build command from intent and slots
      String command = _buildCommand(intent, slots);
      _onCommandDetected?.call(command);
    } else {
      _onCommandDetected?.call('unknown');
    }
  }

  String _buildCommand(String intent, Map<String, dynamic> slots) {
    switch (intent) {
      case 'sendSMS':
        final contact = slots['contact'] ?? '';
        final message = slots['message'] ?? '';
        return 'send SMS to \$contact saying \$message';
      case 'makeCall':
        final contact = slots['contact'] ?? '';
        return 'call \$contact';
      case 'toggleFlashlight':
        return 'toggle flashlight';
      case 'setAlarm':
        final time = slots['time'] ?? '';
        return 'set alarm for \$time';
      case 'openApp':
        final app = slots['app'] ?? '';
        return 'open \$app';
      default:
        return intent;
    }
  }

  void dispose() {
    _picovoiceManager?.delete();
    _picovoiceManager = null;
  }
}
