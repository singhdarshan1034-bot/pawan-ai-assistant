import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:torch_controller/torch_controller.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:app_settings/app_settings.dart';

class ExtendedDeviceController {
  final TorchController _torch = TorchController();
  static const MethodChannel _platform = MethodChannel('com.pawan.ai/device');

  // WiFi Control
  Future<void> toggleWiFi() async {
    try {
      await AppSettings.openAppSettings(type: AppSettingsType.wifi);
    } catch (e) {
      debugPrint('WiFi toggle error: \$e');
    }
  }

  // Bluetooth Control
  Future<void> toggleBluetooth() async {
    try {
      await AppSettings.openAppSettings(type: AppSettingsType.bluetooth);
    } catch (e) {
      debugPrint('Bluetooth toggle error: \$e');
    }
  }

  // Volume Control
  Future<void> setVolume(double level) async {
    try {
      await _platform.invokeMethod('setVolume', {'level': level});
    } catch (e) {
      debugPrint('Volume control error: \$e');
    }
  }

  // Screen Brightness
  Future<void> setBrightness(double level) async {
    try {
      await _platform.invokeMethod('setBrightness', {'level': level});
    } catch (e) {
      debugPrint('Brightness control error: \$e');
    }
  }

  // Airplane Mode
  Future<void> toggleAirplaneMode() async {
    try {
      await AppSettings.openAppSettings(type: AppSettingsType.airplaneMode);
    } catch (e) {
      debugPrint('Airplane mode error: \$e');
    }
  }

  // Mobile Data
  Future<void> toggleMobileData() async {
    try {
      await AppSettings.openAppSettings(type: AppSettingsType.dataRoaming);
    } catch (e) {
      debugPrint('Mobile data error: \$e');
    }
  }

  // Do Not Disturb
  Future<void> toggleDoNotDisturb() async {
    try {
      await AppSettings.openAppSettings(type: AppSettingsType.notification);
    } catch (e) {
      debugPrint('DND error: \$e');
    }
  }

  // Open Specific Settings
  Future<void> openSettings(String type) async {
    switch (type.toLowerCase()) {
      case 'wifi':
        await AppSettings.openAppSettings(type: AppSettingsType.wifi);
        break;
      case 'bluetooth':
        await AppSettings.openAppSettings(type: AppSettingsType.bluetooth);
        break;
      case 'location':
        await AppSettings.openAppSettings(type: AppSettingsType.location);
        break;
      case 'security':
        await AppSettings.openAppSettings(type: AppSettingsType.security);
        break;
      case 'display':
        await AppSettings.openAppSettings(type: AppSettingsType.display);
        break;
      case 'sound':
        await AppSettings.openAppSettings(type: AppSettingsType.sound);
        break;
      case 'battery':
        await AppSettings.openAppSettings(type: AppSettingsType.batteryOptimization);
        break;
      default:
        await AppSettings.openAppSettings();
    }
  }

  // Take Screenshot
  Future<void> takeScreenshot() async {
    try {
      await _platform.invokeMethod('takeScreenshot');
    } catch (e) {
      debugPrint('Screenshot error: \$e');
    }
  }

  // Lock Screen
  Future<void> lockScreen() async {
    try {
      await _platform.invokeMethod('lockScreen');
    } catch (e) {
      debugPrint('Lock screen error: \$e');
    }
  }

  // Vibrate
  Future<void> vibrate({int duration = 500}) async {
    try {
      await _platform.invokeMethod('vibrate', {'duration': duration});
    } catch (e) {
      HapticFeedback.mediumImpact();
    }
  }

  // Get Battery Level
  Future<int> getBatteryLevel() async {
    try {
      final result = await _platform.invokeMethod('getBatteryLevel');
      return result ?? -1;
    } catch (e) {
      return -1;
    }
  }

  // Get Device Info
  Future<Map<String, dynamic>> getDeviceInfo() async {
    try {
      final result = await _platform.invokeMethod('getDeviceInfo');
      return Map<String, dynamic>.from(result ?? {});
    } catch (e) {
      return {};
    }
  }

  // Launch URL
  Future<void> launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrlString(uri.toString());
    }
  }

  // Open Maps
  Future<void> openMaps(String location) async {
    final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=\$location');
    if (await canLaunchUrl(uri)) {
      await launchUrlString(uri.toString());
    }
  }

  // Open Browser
  Future<void> openBrowser(String url) async {
    final uri = Uri.parse(url.startsWith('http') ? url : 'https://\$url');
    if (await canLaunchUrl(uri)) {
      await launchUrlString(uri.toString(), mode: LaunchMode.externalApplication);
    }
  }

  // Share Text
  Future<void> shareText(String text) async {
    final uri = Uri.parse('sms:?body=\$text');
    if (await canLaunchUrl(uri)) {
      await launchUrlString(uri.toString());
    }
  }

  // Open Calculator
  Future<void> openCalculator() async {
    try {
      await _platform.invokeMethod('openCalculator');
    } catch (e) {
      // Fallback to browser calculator
      await openBrowser('calculator.com');
    }
  }

  // Open Calendar
  Future<void> openCalendar() async {
    try {
      await _platform.invokeMethod('openCalendar');
    } catch (e) {
      await openBrowser('calendar.google.com');
    }
  }

  // Open Music Player
  Future<void> openMusicPlayer() async {
    try {
      await _platform.invokeMethod('openMusicPlayer');
    } catch (e) {
      debugPrint('Music player error: \$e');
    }
  }

  // Start Timer
  Future<void> startTimer(int minutes) async {
    try {
      await _platform.invokeMethod('startTimer', {'minutes': minutes});
    } catch (e) {
      debugPrint('Timer error: \$e');
    }
  }

  // Start Stopwatch
  Future<void> startStopwatch() async {
    try {
      await _platform.invokeMethod('startStopwatch');
    } catch (e) {
      debugPrint('Stopwatch error: \$e');
    }
  }

  // Enable/Disable Auto-Rotate
  Future<void> toggleAutoRotate() async {
    try {
      await _platform.invokeMethod('toggleAutoRotate');
    } catch (e) {
      debugPrint('Auto-rotate error: \$e');
    }
  }

  // Enable/Disable NFC
  Future<void> toggleNFC() async {
    try {
      await AppSettings.openAppSettings(type: AppSettingsType.nfc);
    } catch (e) {
      debugPrint('NFC error: \$e');
    }
  }

  // Hotspot Control
  Future<void> toggleHotspot() async {
    try {
      await _platform.invokeMethod('toggleHotspot');
    } catch (e) {
      debugPrint('Hotspot error: \$e');
    }
  }

  // Find My Phone (Ring even if silent)
  Future<void> findMyPhone() async {
    try {
      await _platform.invokeMethod('findMyPhone');
    } catch (e) {
      // Fallback: vibrate and play sound
      await vibrate(duration: 2000);
    }
  }

  // Mirror Screen (Cast)
  Future<void> mirrorScreen() async {
    try {
      await _platform.invokeMethod('mirrorScreen');
    } catch (e) {
      debugPrint('Screen mirror error: \$e');
    }
  }

  // Record Audio
  Future<void> startRecording() async {
    try {
      await _platform.invokeMethod('startRecording');
    } catch (e) {
      debugPrint('Recording error: \$e');
    }
  }

  Future<void> stopRecording() async {
    try {
      await _platform.invokeMethod('stopRecording');
    } catch (e) {
      debugPrint('Stop recording error: \$e');
    }
  }

  // Clipboard Operations
  Future<void> copyToClipboard(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
  }

  Future<String?> pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    return data?.text;
  }

  // Speak Clipboard Content
  Future<String?> getClipboardContent() async {
    return await pasteFromClipboard();
  }
}
