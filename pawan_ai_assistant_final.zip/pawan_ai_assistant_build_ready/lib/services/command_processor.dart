import '../models/command_model.dart';

class CommandProcessor {
  DeviceAction parseDeviceCommand(String command) {
    final lower = command.toLowerCase();

    if (lower.contains('send') && lower.contains('sms') || 
        lower.contains('text') || lower.contains('message')) {
      return DeviceAction.sendSMS;
    }
    if (lower.contains('call') || lower.contains('dial')) {
      return DeviceAction.makeCall;
    }
    if (lower.contains('flashlight') || lower.contains('torch')) {
      return DeviceAction.toggleFlashlight;
    }
    if (lower.contains('open') && lower.contains('app')) {
      return DeviceAction.openApp;
    }
    if (lower.contains('alarm') || lower.contains('wake me')) {
      return DeviceAction.setAlarm;
    }
    if (lower.contains('photo') || lower.contains('camera') || lower.contains('selfie')) {
      return DeviceAction.takePhoto;
    }

    return DeviceAction.unknown;
  }
}
