package com.pawan.ai

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.telephony.SmsManager
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.view.WindowManager

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.pawan.ai/device"
    private lateinit var cameraManager: CameraManager
    private lateinit var audioManager: AudioManager
    private lateinit var powerManager: PowerManager
    private var cameraId: String? = null
    private var isFlashOn = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager

        try {
            cameraId = cameraManager.cameraIdList[0]
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "toggleFlashlight" -> toggleFlashlight(result)
                "sendSMS" -> {
                    val phoneNumber = call.argument<String>("phoneNumber")
                    val message = call.argument<String>("message")
                    sendSMS(phoneNumber, message, result)
                }
                "makeCall" -> {
                    val phoneNumber = call.argument<String>("phoneNumber")
                    makeCall(phoneNumber, result)
                }
                "setAlarm" -> {
                    val hour = call.argument<Int>("hour") ?: 7
                    val minute = call.argument<Int>("minute") ?: 0
                    setAlarm(hour, minute, result)
                }
                "openCamera" -> openCamera(result)
                "setVolume" -> {
                    val level = call.argument<Double>("level") ?: 0.5
                    setVolume(level, result)
                }
                "setBrightness" -> {
                    val level = call.argument<Double>("level") ?: 0.5
                    setBrightness(level, result)
                }
                "takeScreenshot" -> takeScreenshot(result)
                "lockScreen" -> lockScreen(result)
                "vibrate" -> {
                    val duration = call.argument<Int>("duration") ?: 500
                    vibrateDevice(duration, result)
                }
                "getBatteryLevel" -> getBatteryLevel(result)
                "getDeviceInfo" -> getDeviceInfo(result)
                "toggleHotspot" -> toggleHotspot(result)
                "findMyPhone" -> findMyPhone(result)
                "mirrorScreen" -> mirrorScreen(result)
                "startRecording" -> startRecording(result)
                "stopRecording" -> stopRecording(result)
                "toggleAutoRotate" -> toggleAutoRotate(result)
                "openCalculator" -> openCalculator(result)
                "openCalendar" -> openCalendar(result)
                "openMusicPlayer" -> openMusicPlayer(result)
                "startTimer" -> {
                    val minutes = call.argument<Int>("minutes") ?: 5
                    startTimer(minutes, result)
                }
                "startStopwatch" -> startStopwatch(result)
                else -> result.notImplemented()
            }
        }
    }

    private fun toggleFlashlight(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                cameraId?.let {
                    isFlashOn = !isFlashOn
                    cameraManager.setTorchMode(it, isFlashOn)
                    result.success(isFlashOn)
                } ?: result.error("UNAVAILABLE", "Camera not available", null)
            } catch (e: CameraAccessException) {
                result.error("ERROR", e.message, null)
            }
        } else {
            result.error("UNAVAILABLE", "Flashlight not supported", null)
        }
    }

    private fun sendSMS(phoneNumber: String?, message: String?, result: MethodChannel.Result) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun makeCall(phoneNumber: String?, result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$phoneNumber")
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun setAlarm(hour: Int, minute: Int, result: MethodChannel.Result) {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun openCamera(result: MethodChannel.Result) {
        try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun setVolume(level: Double, result: MethodChannel.Result) {
        try {
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val newVolume = (level * maxVolume).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, AudioManager.FLAG_SHOW_UI)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun setBrightness(level: Double, result: MethodChannel.Result) {
        try {
            val brightness = (level * 255).toInt()
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, brightness)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun takeScreenshot(result: MethodChannel.Result) {
        try {
            // Screenshot requires system-level permissions
            // For now, we'll use the media projection API
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun lockScreen(result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_SCREEN_OFF)
            sendBroadcast(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun vibrateDevice(duration: Int, result: MethodChannel.Result) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager
                vibratorManager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(android.os.VibrationEffect.createOneShot(duration.toLong(), android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(duration.toLong())
            }
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun getBatteryLevel(result: MethodChannel.Result) {
        try {
            val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level != -1 && scale != -1) {
                (level.toFloat() / scale.toFloat() * 100).toInt()
            } else {
                -1
            }
            result.success(batteryPct)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun getDeviceInfo(result: MethodChannel.Result) {
        try {
            val info = HashMap<String, Any>()
            info["model"] = Build.MODEL
            info["manufacturer"] = Build.MANUFACTURER
            info["version"] = Build.VERSION.RELEASE
            info["sdk"] = Build.VERSION.SDK_INT
            info["brand"] = Build.BRAND
            info["device"] = Build.DEVICE
            result.success(info)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun toggleHotspot(result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_MAIN)
            intent.setClassName("com.android.settings", "com.android.settings.TetherSettings")
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun findMyPhone(result: MethodChannel.Result) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager
                vibratorManager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(android.os.VibrationEffect.createOneShot(3000, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(3000)
            }
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun mirrorScreen(result: MethodChannel.Result) {
        try {
            val intent = Intent("android.settings.CAST_SETTINGS")
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun startRecording(result: MethodChannel.Result) {
        try {
            val intent = Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION)
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun stopRecording(result: MethodChannel.Result) {
        result.success(true)
    }

    private fun toggleAutoRotate(result: MethodChannel.Result) {
        try {
            val currentSetting = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION)
            val newSetting = if (currentSetting == 1) 0 else 1
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, newSetting)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun openCalculator(result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_APP_CALCULATOR)
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun openCalendar(result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("content://com.android.calendar/time/" + System.currentTimeMillis())
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun openMusicPlayer(result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.type = "audio/*"
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun startTimer(minutes: Int, result: MethodChannel.Result) {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun startStopwatch(result: MethodChannel.Result) {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_STOPWATCH)
            startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }
}
